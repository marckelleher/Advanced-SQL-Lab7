/*
Marc Kelleher
CIS 276
Lab 7
3/3/18
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

CREATE OR REPLACE TRIGGER InsertOrderItemsTRG
BEFORE INSERT ON ORDERITEMS
FOR EACH ROW

DECLARE

  Not_Enough_Stock  EXCEPTION;
  PRAGMA EXCEPTION_INIT(Not_Enough_Stock, -20101);

BEGIN

  --Assign new value to Detail column:
  SELECT  NVL(MAX(OI.Detail), 0) + 1 
  INTO    :new.Detail
  FROM    ORDERITEMS OI
  WHERE   OrderID = :new.OrderID;

  --Update INVENTORY.StockQty:
  UPDATE  INVENTORY
  SET     StockQty = (StockQty - :new.Qty)
  WHERE   PartID = :new.PartID;

EXCEPTION

  WHEN Not_Enough_Stock THEN
    RAISE;
  WHEN OTHERS THEN  
    RAISE;
    
END;
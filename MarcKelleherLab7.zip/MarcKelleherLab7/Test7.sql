/*
Marc Kelleher
CIS 276
Lab 7
3/3/18
*/

--Test condition:  All valid input values:

CustID:   1
OrderID:  6099
PartID:   1002
Qty:      1

BEFORE running program:

Highest Detail line item from OrderItems:
OrderID   Detail    PartID    Qty
6099	    5	        1002	    1

Inventory:    

PartID    Description   StockQty    ReOrderPnt    Price
1002	    doohickey   	69	        25	          25
      
AFTER running program:      

New line item in OrderItems:
OrderID   Detail    PartID    Qty
6099	    6	        1002	    1

New inventory:

PartID    Description   StockQty    ReOrderPnt    Price
1002	    doohickey   	68	        25	          25

--Test condition:  Invalid Customer ID

CustID:   0
OrderID:  6099
PartID:   1002
Qty:      1

Result:
anonymous block completed
NO_DATA_FOUND exception:
CustID 0 is invalid.   

--Test condition:  Invalid Order ID

CustID:   1
OrderID:  0
PartID:   1002
Qty:      1

Result:
anonymous block completed
NO_DATA_FOUND exception:
OrderID 0 is invalid.

--Test condition:  Invalid Part ID:

CustID:   1
OrderID:  6099
PartID:   0
Qty:      1

Result:
anonymous block completed
NO_DATA_FOUND exception:
PartID 0 is invalid.
       

--Test condition:  Invalid quantity:

CustID:   1
OrderID:  6099
PartID:   1002
Qty:      0

Result:
anonymous block completed
Not a valid quantity.
Quantity entered of 0 is invalid.

--Test condition:  CustID not associated with OrderID:

CustID:   2
OrderID:  6099
PartID:   1002
Qty:      1

Result:
anonymous block completed
NO_DATA_FOUND exception:
CustID 2 is not associated with OrderID 6099.

--Test condition:  Resulting StockQty < 0

CustID:   1
OrderID:  6099
PartID:   1002
Qty:      100

BEFORE running program:

Highest Detail line item from OrderItems:
OrderID   Detail    PartID    Qty
6099	    5	        1002	    1
      
Inventory:      
PartID    Description   StockQty    ReOrderPnt    Price
1002	    doohickey   	69	        25	          25
      
AFTER running program:      

New order:  N/A
Highest Detail line item from OrderItems:
OrderID   Detail    PartID    Qty
6099	    5	        1002	    1

Inventory:
PartID    Description   StockQty    ReOrderPnt    Price
1002	    doohickey   	69	        25	          25

Result:
anonymous block completed
UPDATE Trigger UpdateInventoryTRG
=========================================
There is not enough stock.
Order quantity greater than stock on hand:
ROLLBACK transaction
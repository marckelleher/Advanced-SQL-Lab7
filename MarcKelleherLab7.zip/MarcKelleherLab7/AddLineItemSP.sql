/*
Marc Kelleher
CIS 276
Lab 7
3/3/18
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

create or replace PROCEDURE 
  AddLineItemSP(vOrderID IN NUMBER, vPartID IN NUMBER, vQty IN NUMBER) 

AS  

  Null_Error  EXCEPTION;
  PRAGMA EXCEPTION_INIT(Null_Error, -20199);
  Not_Enough_Stock  EXCEPTION;
  PRAGMA EXCEPTION_INIT(Not_Enough_Stock, -20101);
  vErrorMessage   CHAR(225) := 'Error Message';

BEGIN

  INSERT INTO ORDERITEMS (OrderID, PartID, Qty)	
  VALUES (vOrderID, vPartID, vQty); 
              
  DBMS_OUTPUT.PUT_LINE('Orderid ' || vOrderid  || ' partid ' || vPartid ||
  ' quantity ' || vQty || ' is good so we can COMMIT the transaction!');
  COMMIT;     
                         
EXCEPTION

  WHEN Not_Enough_Stock THEN
    DBMS_OUTPUT.PUT_LINE('Order quantity greater than stock on hand:'); 
    DBMS_OUTPUT.PUT_LINE('ROLLBACK transaction'); 
    ROLLBACK;
    
  WHEN Null_Error THEN  
    DBMS_OUTPUT.PUT_LINE('Cannot insert null value into Detail:'); 
    DBMS_OUTPUT.PUT_LINE('ROLLBACK transaction'); 
    ROLLBACK;
    
  WHEN OTHERS THEN 
    vErrorMessage := SQLERRM; 
    DBMS_OUTPUT.PUT_LINE ('The program encountered the following error: '); 
    DBMS_OUTPUT.PUT_LINE (vErrorMessage); 
    ROLLBACK;

END;
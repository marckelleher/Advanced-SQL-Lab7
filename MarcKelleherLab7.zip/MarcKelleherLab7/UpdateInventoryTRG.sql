/*
Marc Kelleher
CIS 276
Lab 7
3/3/18
*/

SET SERVEROUTPUT ON FORMAT WRAPPED

CREATE OR REPLACE TRIGGER UpdateInventory
BEFORE UPDATE ON INVENTORY
FOR EACH ROW

DECLARE
  
  Not_Enough_Stock  EXCEPTION;
  PRAGMA EXCEPTION_INIT(Not_Enough_Stock, -20101);

BEGIN

  IF :new.StockQty < 0 THEN
  RAISE Not_Enough_Stock;
  END IF;
    
EXCEPTION

  WHEN Not_Enough_Stock THEN
    DBMS_OUTPUT.PUT_LINE('UPDATE Trigger UpdateInventoryTRG');
    DBMS_OUTPUT.PUT_LINE('=========================================');
    DBMS_OUTPUT.PUT_LINE('There is not enough stock.');
    RAISE;
    
  WHEN OTHERS THEN
    RAISE;
    
END; 
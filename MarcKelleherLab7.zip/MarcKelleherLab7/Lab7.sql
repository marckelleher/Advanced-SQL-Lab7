/*
Marc Kelleher
CIS 276
Lab 7
3/3/18
*/

SET SERVEROUTPUT ON FORMAT WORD_WRAPPED

--Main lab for input validation:
DECLARE 

    -- Input variables
    vCustID         NUMBER := &1;
    vOrderID        NUMBER := &2;
    vPartID         NUMBER := &3;
    vQty            NUMBER := &4;
    -- Validation variables:
    vCname      	  CUSTOMERS.cname%TYPE := 'No customer name';
    vSalesdate      ORDERS.Salesdate%TYPE :=SYSDATE;
    vDescription	  INVENTORY.description%TYPE := 'No part';
    -- Processing variables:
    vDetail 		    NUMBER(2);	--New detail line number
    vStockQty		    NUMBER(4);	--Inventory stock quantity
	  vMsg            VARCHAR2(120) := 'No message';
    vMsg2           VARCHAR2(120) := 'No message';
    BadQty          EXCEPTION;  --For input quantity error
    vErrorMessage   CHAR(225) := 'Error Message';

--Main block for customer validation:
BEGIN 
 
    --NO_DATA_FOUND exception means input CustID is invalid.
    vMsg := 'CustID ' || vCustID || ' is invalid.';
    vMsg2:= 'You must enter a number';
    SELECT CName
    INTO   vCName
    FROM   CUSTOMERS
    WHERE  CustID = vCustID;
        
    --Second block for order validation:
    BEGIN  
    
        --NO_DATA_FOUND exception means input orderid is invalid 
		    vMsg := 'OrderID ' || vOrderID || ' is invalid.';
        SELECT SalesDate
        INTO   vSalesDate 
        FROM   ORDERS
        WHERE  OrderID = vOrderID;

		    --Check for valid CustID/OrderID pair:
        vMsg := 'CustID ' || vCustID || 
                ' is not associated with OrderID ' || vOrderID || '.';
        SELECT salesdate
		    INTO   vSalesdate
		    FROM   ORDERS
		    WHERE  orderid = vOrderID
		    AND    custid = vCustID;
		
        --Third block for inventory validation:
        BEGIN  
 
			      -- If input PartID not in INVENTORY, NO_DATA_FOUND exception.
            vMsg := 'PartID ' || vPartID || ' is invalid.';
            SELECT description 
            INTO   vDescription
            FROM   INVENTORY
            WHERE  partid = vPartID;
            
            --Fourth, inner-most block:
            BEGIN   

				        vMsg := 'Quantity entered of ' || vQty || ' is invalid.';
                IF vQty < 1 THEN
                    RAISE BadQty;
                END IF;
                
                --Call the procedure after input validation:
                AddLineItemSP(vOrderID, vPartID, vQty);

            EXCEPTION  -- fourth block EXCEPTION handler
 
                WHEN BadQty THEN
                    DBMS_OUTPUT.PUT_LINE ('Not a valid quantity.'); 
                    DBMS_OUTPUT.PUT_LINE (vMsg); 
                    ROLLBACK;
                WHEN OTHERS THEN
					          vMsg := SQLERRM; 
                    DBMS_OUTPUT.PUT_LINE (vMsg);
                    ROLLBACK;					
            END; 
            
        EXCEPTION  -- third block EXCEPTION handler
 
            WHEN NO_DATA_FOUND THEN 
                DBMS_OUTPUT.PUT_LINE ('NO_DATA_FOUND exception:'); 
                DBMS_OUTPUT.PUT_LINE (vMsg); 
            WHEN OTHERS THEN 
                vMsg := SQLERRM; 				
                DBMS_OUTPUT.PUT_LINE (vMsg); 
        END; 

    EXCEPTION  -- second block EXCEPTION handler
 
        WHEN NO_DATA_FOUND THEN 
            DBMS_OUTPUT.PUT_LINE ('NO_DATA_FOUND exception:'); 
            DBMS_OUTPUT.PUT_LINE (vMsg); 
        WHEN OTHERS THEN 
            vMsg := SQLERRM; 
            DBMS_OUTPUT.PUT_LINE (vMsg); 
    END; 
     
EXCEPTION -- main block EXCEPTION handler
 
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE ('NO_DATA_FOUND exception:'); 
        DBMS_OUTPUT.PUT_LINE (vMsg);
    
    WHEN OTHERS THEN 
	      vMsg := SQLERRM; 
        DBMS_OUTPUT.PUT_LINE (vMsg); 
        
END;
/